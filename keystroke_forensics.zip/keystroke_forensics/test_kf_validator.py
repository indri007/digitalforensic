import copy
import json
import os
import tempfile
import unittest
from datetime import timedelta

import make_sample as ms
from kf_validator import GENESIS, event_hash, validate

CFG = {"require_pq": False}  # liboqs tidak selalu ada; tanda tangan PQC diuji terpisah bila tersedia


def status(report, rid):
    return next(r["status"] for r in report["results"] if r["id"] == rid)


def rehash_chain(events):
    prev = GENESIS
    for i, e in enumerate(events):
        e["seq"], e["prev_hash"] = i, prev
        e["hash"] = event_hash(e)
        prev = e["hash"]


class Base(unittest.TestCase):
    def setUp(self):
        self.session, self.events = ms.simulate("human", seed=1)
        self.bundle = ms.make_bundle(self.session, self.events)
        self.docx = ms.make_docx(self.session)
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def run_validate(self, session=None, events=None, bundle=None, docx=None, cfg=CFG):
        path = None
        data = self.docx if docx is None else docx
        if data:
            path = os.path.join(self.tmp.name, "d.docx")
            with open(path, "wb") as f:
                f.write(data)
        return validate(session or self.session, events or self.events, bundle or self.bundle, path, cfg)


class TestHappyPath(Base):
    def test_clean_session_passes_integrity_and_consistency(self):
        r = self.run_validate()
        for rid in ("V1", "V2", "V3", "V4", "V4b", "V5", "V6", "V8", "V9", "V10", "V11", "C1", "C2", "C3", "C4", "C7", "C9", "C10"):
            self.assertEqual(status(r, rid), "pass", (rid, r["results"]))
        self.assertEqual(r["decision"], "no_validator_decision")
        self.assertTrue(r["integrity_fully_verified"])

    def test_missing_pq_signature_fails_when_required(self):
        r = self.run_validate(cfg={})
        self.assertEqual(status(r, "V10"), "fail")
        self.assertEqual(r["decision"], "evidence_integrity_failure")

    def test_too_few_events_is_inconclusive(self):
        s, e = ms.simulate("human", seed=2, n_chars=10)
        b = ms.make_bundle(s, e)
        r = validate(s, e, b, None, {**CFG, "min_events_for_decision": 100000})
        self.assertEqual(r["decision"], "inconclusive_insufficient_data")


class TestTamper(Base):
    def test_edited_event_breaks_hash_and_arithmetic(self):
        ev = copy.deepcopy(self.events)
        ev[10]["inserted_len"] += 5
        r = self.run_validate(events=ev)
        self.assertEqual(status(r, "V9"), "fail")
        self.assertEqual(status(r, "V4"), "fail")
        self.assertEqual(r["decision"], "evidence_integrity_failure")

    def test_removed_event_breaks_sequence_and_chain(self):
        ev = copy.deepcopy(self.events)
        del ev[20]
        r = self.run_validate(events=ev)
        self.assertEqual(status(r, "V1"), "fail")
        self.assertEqual(status(r, "V3"), "fail")
        self.assertEqual(status(r, "V6"), "fail")

    def test_recomputed_chain_is_caught_by_signed_bundle(self):
        """Penyerang menghitung ulang seluruh rantai setelah mengedit: rantai konsisten, tapi bundle bertanda tangan tidak cocok."""
        ev = copy.deepcopy(self.events)
        ev[10]["t_ms"] += 7
        for e in ev[10:]:
            e["t_ms"] += 7
        rehash_chain(ev)
        r = self.run_validate(events=ev)
        self.assertEqual(status(r, "V3"), "pass")
        self.assertEqual(status(r, "V9"), "pass")
        self.assertEqual(status(r, "V6"), "fail")
        self.assertEqual(r["decision"], "evidence_integrity_failure")

    def test_altered_bundle_invalidates_signature(self):
        b = copy.deepcopy(self.bundle)
        b["key_id"] = "other"
        r = self.run_validate(bundle=b)
        self.assertEqual(status(r, "V10"), "fail")

    def test_time_going_backwards(self):
        ev = copy.deepcopy(self.events)
        ev[30]["t_ms"] = ev[29]["t_ms"] - 1
        rehash_chain(ev)
        r = self.run_validate(events=ev)
        self.assertEqual(status(r, "V2"), "fail")

    def test_unsupported_schema_version(self):
        s = copy.deepcopy(self.session)
        s["schema_version"] = "9.9"
        r = self.run_validate(session=s)
        self.assertEqual(status(r, "V8"), "fail")

    def test_tsa_time_outside_window(self):
        b = copy.deepcopy(self.bundle)
        b["tsa_time"] = (ms.parse(self.session["t_start"]) - timedelta(days=2)).isoformat()
        r = self.run_validate(bundle=b)
        self.assertEqual(status(r, "V11"), "fail")


class TestDocx(Base):
    def test_unreferenced_part_detected(self):
        d = ms.make_docx(self.session, extra_parts={"word/media/hidden.bin": "x"})
        r = self.run_validate(docx=d)
        self.assertEqual(status(r, "C7"), "fail")
        self.assertEqual(r["decision"], "inconsistent_log_document")

    def test_entry_time_outside_session_window(self):
        d = ms.make_docx(self.session, entry_time=ms.parse(self.session["t_start"]) - timedelta(days=3))
        r = self.run_validate(docx=d)
        self.assertEqual(status(r, "C7"), "fail")

    def test_modified_after_session(self):
        d = ms.make_docx(self.session, modified=ms.parse(self.session["t_end"]) + timedelta(days=1))
        r = self.run_validate(docx=d)
        self.assertEqual(status(r, "C4"), "fail")

    def test_wrong_producer(self):
        d = ms.make_docx(self.session, application="python-docx")
        r = self.run_validate(docx=d)
        self.assertEqual(status(r, "C9"), "fail")

    def test_not_a_zip(self):
        r = self.run_validate(docx=b"bukan zip")
        self.assertEqual(status(r, "C7"), "fail")

    def test_rsid_is_informational_only(self):
        r = self.run_validate()
        c8 = next(x for x in r["results"] if x["id"] == "C8")
        self.assertEqual(c8["status"], "info")
        self.assertEqual(c8["rsid_count"], 2)

    def test_log_final_length_mismatch(self):
        s = copy.deepcopy(self.session)
        s["final_length"] += 3
        r = self.run_validate(session=s)
        self.assertEqual(status(r, "C1"), "fail")


class TestPlausibilityAndFeatures(Base):
    def test_synthetic_source_flagged(self):
        ev = copy.deepcopy(self.events)
        for e in ev[5:60]:
            if e["type"] == "key_down":
                e["source"] = "synthetic"
        rehash_chain(ev)
        b = ms.make_bundle(self.session, ev)
        r = self.run_validate(events=ev, bundle=b)
        self.assertEqual(status(r, "P6"), "flag")

    def test_paste_session_flags_d1(self):
        s, e = ms.simulate("paste", seed=3)
        b = ms.make_bundle(s, e)
        r = validate(s, e, b, None, {**CFG, "min_events_for_decision": 1})
        self.assertEqual(status(r, "D1"), "flag")
        self.assertAlmostEqual(r["features"]["paste_ratio"], 1.0)

    def test_copy_type_has_low_variability_and_no_revision(self):
        s, e = ms.simulate("copy_type", seed=4)
        b = ms.make_bundle(s, e)
        r = validate(s, e, b, None, CFG)
        self.assertEqual(r["features"]["delete_ratio"], 0.0)
        self.assertEqual(status(r, "D2"), "flag")

    def test_human_sim_does_not_trigger_copy_type_cue(self):
        r = self.run_validate()
        self.assertEqual(status(r, "D2"), "pass")
        self.assertGreater(r["features"]["delete_ratio"], 0.03)


if __name__ == "__main__":
    unittest.main()
