#!/usr/bin/env python3
"""Generator sesi simulasi untuk menguji kf_validator. DATA SIMULASI, bukan data peserta.

  python3 -I make_sample.py examples     # tulis contoh ke folder examples/
"""
import base64
import io
import json
import math
import random
import sys
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

from kf_validator import GENESIS, event_hash, merkle_root, signed_manifest

TZ = timezone(timedelta(hours=7))
T_START = datetime(2026, 10, 15, 14, 0, 0, tzinfo=TZ)


def simulate(kind="human", seed=0, n_chars=400, expected_application="Microsoft Office Word"):
    """kind: human | copy_type | paste. Mengembalikan (session, events)."""
    rng = random.Random(seed)
    events, t, length = [], 0, 0

    def emit(**kw):
        nonlocal length
        ev = {"seq": len(events), "t_ms": t, "wall_ts": (T_START + timedelta(milliseconds=t)).isoformat(),
              "type": "key_down", "key_class": "letter", "pos": length, "len_before": length,
              "len_after": length, "inserted_len": 0, "deleted_len": 0, "source": "typed"}
        ev.update(kw)
        ev["len_after"] = ev["len_before"] + ev["inserted_len"] - ev["deleted_len"]
        length = ev["len_after"]
        ev["prev_hash"] = events[-1]["hash"] if events else GENESIS
        ev["hash"] = event_hash(ev)
        events.append(ev)

    if kind == "paste":
        t = 20000
        emit(type="paste", key_class="none", inserted_len=n_chars, source="paste")
    else:
        t = 3000 if kind == "human" else 20000
        sigma = 0.55 if kind == "human" else 0.25
        typed = 0
        while typed < n_chars:
            t += int(rng.lognormvariate(math.log(170), sigma))
            if kind == "human" and typed > 5 and rng.random() < 0.10 and length > 0:
                emit(key_class="backspace", deleted_len=1)
                t += 40
                emit(type="key_up", key_class="backspace", source="typed")
                continue
            if kind == "human" and rng.random() < 0.03:
                t += rng.randint(1200, 1900)
            emit(key_class="space" if rng.random() < 0.15 else "letter", inserted_len=1)
            typed += 1
            t += 60
            emit(type="key_up", key_class="letter", source="typed")
    t_end = T_START + timedelta(milliseconds=t) + timedelta(minutes=2)
    snaps = [{"seq": e["seq"], "t_ms": e["t_ms"], "length": e["len_after"], "doc_hash": "a" * 64}
             for e in events[::100]]
    session = {
        "schema_version": "1.0", "app_version": "sim-0.1", "session_id": f"sim-{kind}-{seed}",
        "participant_id": f"P{seed:03d}", "task_id": "T1",
        "condition": {"human": "human", "copy_type": "copy_type", "paste": "paste_ai"}[kind],
        "lang": "id", "device": "sim", "layout": "qwerty", "t_start": T_START.isoformat(),
        "t_end": t_end.isoformat(), "tz_offset_min": 420, "word_app_version": "16.0",
        "expected_application": expected_application, "consent_version": "v1",
        "final_length": length, "snapshots": snaps,
    }
    return session, events


def make_bundle(session, events, sign=True, seed=0):
    bundle = {
        "session_id": session["session_id"], "schema_version": "1.0", "event_count": len(events),
        "chain_head": events[-1]["hash"], "merkle_root": merkle_root([e["hash"] for e in events]),
        "alg_ids": {"classical": "ecdsa-p256-sha256", "pq": "ML-DSA-65"},
        "alg_allowlist_version": "1", "key_id": "sim-key-1", "created_at": session["t_end"],
        "tsa_time": (parse(session["t_end"]) + timedelta(minutes=1)).isoformat(),  # SIMULASI, bukan token RFC 3161
    }
    if sign:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import ec
        key = ec.generate_private_key(ec.SECP256R1())
        pub = key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
        sig = key.sign(signed_manifest(bundle), ec.ECDSA(hashes.SHA256()))
        bundle["sig_classical"] = {"alg": "ecdsa-p256-sha256", "signature_b64": base64.b64encode(sig).decode(),
                                   "public_key_b64": base64.b64encode(pub).decode()}
        try:  # tanda tangan PQC hanya bila liboqs-python terpasang
            import oqs
            with oqs.Signature("ML-DSA-65") as s:
                pk = s.generate_keypair()
                psig = s.sign(signed_manifest(bundle))
            bundle["sig_pq"] = {"alg": "ML-DSA-65", "signature_b64": base64.b64encode(psig).decode(),
                                "public_key_b64": base64.b64encode(pk).decode()}
        except Exception:
            pass
    return bundle


def parse(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def make_docx(session, extra_parts=None, entry_time=None, application="Microsoft Office Word",
              created=None, modified=None, total_time=1):
    """Docx minimal (bukan keluaran Word asli). Hanya untuk menguji parser."""
    t_start, t_end = parse(session["t_start"]), parse(session["t_end"])
    et = (entry_time or (t_end - timedelta(minutes=1))).astimezone(t_start.tzinfo)
    created = (created or t_start).astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    modified = (modified or (t_end - timedelta(minutes=1))).astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    parts = {
        "[Content_Types].xml": '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/></Types>',
        "_rels/.rels": '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="core" Target="docProps/core.xml"/><Relationship Id="rId3" Type="app" Target="docProps/app.xml"/></Relationships>',
        "word/document.xml": '<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p w:rsidR="00A1B2C3" w:rsidRDefault="00D4E5F6"><w:r><w:t>teks contoh</w:t></w:r></w:p></w:body></w:document>',
        "docProps/core.xml": f'<?xml version="1.0" encoding="UTF-8"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dcterms="http://purl.org/dc/terms/"><dcterms:created>{created}</dcterms:created><dcterms:modified>{modified}</dcterms:modified></cp:coreProperties>',
        "docProps/app.xml": f'<?xml version="1.0" encoding="UTF-8"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>{application}</Application><TotalTime>{total_time}</TotalTime></Properties>',
    }
    parts.update(extra_parts or {})
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in parts.items():
            zi = zipfile.ZipInfo(name, date_time=(et.year, et.month, et.day, et.hour, et.minute, et.second))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(zi, data)
    return buf.getvalue()


def write_example(folder, kind, seed=0, tamper=None):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    session, events = simulate(kind, seed)
    bundle = make_bundle(session, events)
    (folder / "session.json").write_text(json.dumps(session, indent=1, ensure_ascii=False), encoding="utf-8")
    (folder / "events.jsonl").write_text("\n".join(json.dumps(e, ensure_ascii=False) for e in events) + "\n", encoding="utf-8")
    (folder / "bundle.json").write_text(json.dumps(bundle, indent=1), encoding="utf-8")
    (folder / "doc.docx").write_bytes(make_docx(session))


if __name__ == "__main__":
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "examples")
    for kind in ("human", "copy_type", "paste"):
        write_example(out / kind, kind, seed=1)
    (out / "config_demo.json").write_text(json.dumps({"require_pq": False}, indent=1), encoding="utf-8")
    print("contoh ditulis ke", out)
