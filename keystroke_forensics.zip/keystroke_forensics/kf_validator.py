#!/usr/bin/env python3
"""
kf_validator: validator aturan V (integritas), C (konsistensi log vs dokumen), P (plausibilitas),
dan fitur D untuk sesi perekaman penulisan.

Prinsip desain
- Validator TIDAK pernah menghasilkan vonis "AI". Ia hanya menyatakan: integritas bukti rusak,
  log dan dokumen tidak konsisten, data tidak cukup, atau "tidak ada keputusan dari validator"
  (flag dan fitur diteruskan ke model). Ini mengikuti aturan R4 dan R6.
- Semua ambang (theta) di DEFAULT_CONFIG adalah PLACEHOLDER. Estimasi dari data pilot sebelum dipakai.
- Hanya dependensi opsional: jsonschema, defusedxml, cryptography (ECDSA), oqs (liboqs-python, PQC).
  Tanpa pustaka itu, aturan terkait berstatus "skip", bukan "pass".

Pemakaian:
  python3 -I kf_validator.py --session session.json --events events.jsonl --bundle bundle.json \
      [--docx dokumen.docx] [--config config.json] [--out report.json]
"""
import argparse
import base64
import hashlib
import json
import posixpath
import statistics
import sys
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:  # XML aman untuk berkas tak tepercaya
    from defusedxml import ElementTree as ET
except ImportError:  # pragma: no cover
    from xml.etree import ElementTree as ET

SUPPORTED_SCHEMA = {"1.0"}
GENESIS = "0" * 64
HERE = Path(__file__).resolve().parent

DEFAULT_CONFIG = {
    # --- integritas ---
    "require_classical": True,
    "require_pq": True,
    "allowed_classical": ["ecdsa-p256-sha256"],
    # Nama algoritma PQC bergantung versi liboqs; sesuaikan dengan yang terpasang.
    "allowed_pq": ["ML-DSA-44", "ML-DSA-65", "ML-DSA-87"],
    "require_tsa": False,
    "tsa_tolerance_min": 5,          # PLACEHOLDER: cap waktu boleh sebelum t_start sebesar ini
    "tsa_max_delay_min": 1440,       # PLACEHOLDER: cap waktu boleh setelah t_end sebesar ini
    "anchor_min_confirmations": 6,   # PLACEHOLDER
    # --- plausibilitas (theta, semua PLACEHOLDER) ---
    "min_intervals_for_stats": 30,
    "iki_max_ms": 2000,
    "theta_min_iki_ms": 10,
    "theta_fast_fraction": 0.05,
    "theta_cv_low": 0.30,
    "theta_wpm_max": 200,
    # --- fitur D (theta, PLACEHOLDER) ---
    "theta_paste_ratio": 0.30,
    "theta_delete_ratio_low": 0.03,
    "theta_initial_pause_ms": 15000,
    # --- konsistensi dokumen ---
    "docx_tolerance_min": 10,        # PLACEHOLDER
    "new_document_expected": True,
    "max_uncompressed_bytes": 100 * 1024 * 1024,
    "max_compression_ratio": 200,
    # --- keputusan ---
    "min_events_for_decision": 50,   # PLACEHOLDER
}

INTEGRITY_IDS = ("V1", "V2", "V3", "V4", "V4b", "V5", "V6", "V8", "V9", "V10", "V11", "V12")


# --------------------------------------------------------------------------- util kripto

def canonical(obj):
    """Serialisasi kanonik: kunci terurut, tanpa spasi, UTF-8. Setara RFC 8785 untuk
    objek yang hanya berisi integer, string, boolean, null (float dilarang oleh schema)."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def event_hash(ev):
    body = {k: v for k, v in ev.items() if k != "hash"}
    return hashlib.sha256(canonical(body).encode("utf-8")).hexdigest()


def merkle_root(hex_hashes):
    """Pohon Merkle bergaya RFC 6962: pemisahan domain leaf (0x00) dan node (0x01);
    node ganjil dinaikkan apa adanya (tanpa duplikasi)."""
    if not hex_hashes:
        return hashlib.sha256(b"").hexdigest()
    level = [hashlib.sha256(b"\x00" + bytes.fromhex(h)).digest() for h in hex_hashes]
    while len(level) > 1:
        nxt = []
        for i in range(0, len(level) - 1, 2):
            nxt.append(hashlib.sha256(b"\x01" + level[i] + level[i + 1]).digest())
        if len(level) % 2:
            nxt.append(level[-1])
        level = nxt
    return level[0].hex()


SIGNED_FIELDS = ("session_id", "schema_version", "event_count", "chain_head", "merkle_root",
                 "alg_ids", "alg_allowlist_version", "key_id", "created_at")


def signed_manifest(bundle):
    """Bytes yang ditandatangani. Cap waktu, jangkar, dan tanda tangan sendiri tidak ikut."""
    return canonical({k: bundle[k] for k in SIGNED_FIELDS if k in bundle}).encode("utf-8")


def _verify_classical(alg, msg, sig_b64, pk_b64):
    """True/False, atau None bila tidak bisa diverifikasi (pustaka tidak ada atau alg tak didukung)."""
    if alg != "ecdsa-p256-sha256":
        return None
    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import ec
    except ImportError:
        return None
    try:
        pk = serialization.load_der_public_key(base64.b64decode(pk_b64))
        pk.verify(base64.b64decode(sig_b64), msg, ec.ECDSA(hashes.SHA256()))
        return True
    except InvalidSignature:
        return False
    except Exception:
        return False


def _verify_pq(alg, msg, sig_b64, pk_b64):
    try:
        import oqs
    except ImportError:
        return None
    try:
        with oqs.Signature(alg) as v:
            return bool(v.verify(msg, base64.b64decode(sig_b64), base64.b64decode(pk_b64)))
    except Exception:
        return None


# --------------------------------------------------------------------------- util umum

def parse_ts(s):
    dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        raise ValueError("timestamp tanpa offset zona waktu: " + s)
    return dt


def _mini_check(instance, schema, path="$"):
    """Pemeriksa schema minimal (required, type, enum, additionalProperties) bila jsonschema tak ada."""
    errs = []
    types = {"integer": int, "string": str, "object": dict, "array": list, "boolean": bool}
    t = schema.get("type")
    if t and not (isinstance(instance, types[t]) and not (t == "integer" and isinstance(instance, bool))):
        return [f"{path}: tipe harus {t}"]
    if "enum" in schema and instance not in schema["enum"]:
        errs.append(f"{path}: nilai di luar enum")
    if isinstance(instance, dict):
        for r in schema.get("required", []):
            if r not in instance:
                errs.append(f"{path}.{r}: wajib ada")
        props = schema.get("properties", {})
        if schema.get("additionalProperties") is False:
            for k in instance:
                if k not in props:
                    errs.append(f"{path}.{k}: field tidak dikenal")
        for k, v in props.items():
            if k in instance and "$ref" not in v:
                errs += _mini_check(instance[k], v, f"{path}.{k}")
    return errs


def schema_errors(instance, schema_name):
    schema = json.loads((HERE / "schemas" / schema_name).read_text(encoding="utf-8"))
    try:
        import jsonschema
        v = jsonschema.Draft202012Validator(schema)
        return [f"{'/'.join(map(str, e.absolute_path)) or '$'}: {e.message}" for e in v.iter_errors(instance)]
    except ImportError:
        return _mini_check(instance, schema)


def _local(tag):
    return tag.rsplit("}", 1)[-1]


# --------------------------------------------------------------------------- validator utama

def validate(session, events, bundle, docx_path=None, config=None):
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    results = []

    def add(rid, status, detail="", **extra):
        results.append({"id": rid, "status": status, "detail": detail, **extra})

    # ---- V8: skema dan versi
    errs = []
    errs += [f"session {e}" for e in schema_errors(session, "session.schema.json")]
    errs += [f"bundle {e}" for e in schema_errors(bundle, "bundle.schema.json")]
    ev_errs = []
    for i, ev in enumerate(events):
        for e in schema_errors(ev, "event.schema.json"):
            ev_errs.append(f"event[{i}] {e}")
    errs += ev_errs
    for name, obj in (("session", session), ("bundle", bundle)):
        if obj.get("schema_version") not in SUPPORTED_SCHEMA:
            errs.append(f"{name} schema_version {obj.get('schema_version')!r} tidak didukung")
    if errs:
        add("V8", "fail", f"{len(errs)} galat skema/versi", errors=errs[:20])
        schema_ok = False
    else:
        add("V8", "pass", "skema dan versi valid")
        schema_ok = True

    feats = {}
    if not schema_ok:
        return _finish(results, cfg, session, events, feats, schema_ok)

    # ---- V1-V5, V9
    v1 = [i for i, e in enumerate(events) if e["seq"] != i]
    add("V1", "fail" if v1 else "pass", f"seq tidak berurutan di indeks {v1[:5]}" if v1 else "seq naik tanpa celah dari 0")

    v2 = [i for i in range(1, len(events)) if events[i]["t_ms"] < events[i - 1]["t_ms"]]
    add("V2", "fail" if v2 else "pass", f"t_ms menurun di indeks {v2[:5]}" if v2 else "t_ms monotonik")

    v3 = []
    prev = GENESIS
    for i, e in enumerate(events):
        if e["prev_hash"] != prev:
            v3.append(i)
        prev = e["hash"]
    add("V3", "fail" if v3 else "pass", f"rantai putus di indeks {v3[:5]}" if v3 else "rantai hash utuh")

    v9 = [i for i, e in enumerate(events) if event_hash(e) != e["hash"]]
    add("V9", "fail" if v9 else "pass",
        f"hash tidak cocok dengan serialisasi kanonik di indeks {v9[:5]}" if v9 else "hash dapat direproduksi dari serialisasi kanonik")

    v4 = [i for i, e in enumerate(events) if e["len_after"] != e["len_before"] + e["inserted_len"] - e["deleted_len"]]
    add("V4", "fail" if v4 else "pass", f"aritmetika panjang salah di indeks {v4[:5]}" if v4 else "len_after = len_before + inserted - deleted")

    v4b = []
    if events and events[0]["len_before"] != 0:
        v4b.append(0)
    v4b += [i for i in range(1, len(events)) if events[i]["len_before"] != events[i - 1]["len_after"]]
    add("V4b", "fail" if v4b else "pass", f"panjang tidak sinambung di indeks {v4b[:5]}" if v4b else "panjang sinambung antar event (dokumen awal kosong)")

    v5 = [i for i, e in enumerate(events) if not (0 <= e["pos"] <= e["len_before"])]
    add("V5", "fail" if v5 else "pass", f"pos di luar rentang di indeks {v5[:5]}" if v5 else "pos dalam rentang")

    # ---- V6: Merkle root, chain head, jumlah event, id sesi
    root = merkle_root([e["hash"] for e in events])
    problems = []
    if root != bundle["merkle_root"]:
        problems.append("merkle_root tidak cocok")
    if events and events[-1]["hash"] != bundle["chain_head"]:
        problems.append("chain_head tidak cocok")
    if len(events) != bundle["event_count"]:
        problems.append(f"event_count {bundle['event_count']} != {len(events)}")
    if bundle["session_id"] != session["session_id"]:
        problems.append("session_id bundle berbeda dengan sesi")
    add("V6", "fail" if problems else "pass", "; ".join(problems) if problems else "Merkle root, chain head, jumlah event, dan id sesi cocok")

    # ---- V10 (V7): tanda tangan hybrid
    _check_signatures(bundle, cfg, add)

    # ---- V11: cap waktu
    t_start, t_end = parse_ts(session["t_start"]), parse_ts(session["t_end"])
    if "tsa_time" in bundle:
        tsa = parse_ts(bundle["tsa_time"])
        lo = t_start - timedelta(minutes=cfg["tsa_tolerance_min"])
        hi = t_end + timedelta(minutes=cfg["tsa_max_delay_min"])
        ok = lo <= tsa <= hi
        add("V11", "pass" if ok else "fail",
            "waktu cap waktu dalam jendela sesi" if ok else "waktu cap waktu di luar jendela sesi",
            note="Token RFC 3161 tidak diparse atau diverifikasi oleh modul ini; hanya waktunya diperiksa.")
    else:
        add("V11", "fail" if cfg["require_tsa"] else "info", "tidak ada cap waktu")

    # ---- V12: jangkar (opsional)
    if "anchor_ref" in bundle:
        c = bundle["anchor_ref"]["confirmations"]
        ok = c >= cfg["anchor_min_confirmations"]
        add("V12", "pass" if ok else "fail", f"konfirmasi {c} (minimum {cfg['anchor_min_confirmations']})",
            note="Hanya memeriksa angka konfirmasi yang dilaporkan; tidak ada kueri jaringan.")
    else:
        add("V12", "info", "tidak ada jangkar blockchain (opsional)")

    # ---- C1-C3, C10: konsistensi internal
    final_len = events[-1]["len_after"] if events else 0
    add("C1", "pass" if session["final_length"] == final_len else "fail",
        f"panjang akhir sesi {session['final_length']} vs hasil replay {final_len}")

    bad_snap = []
    for s in session.get("snapshots", []):
        if s["seq"] >= len(events) or events[s["seq"]]["len_after"] != s["length"] or events[s["seq"]]["t_ms"] != s["t_ms"]:
            bad_snap.append(s["seq"])
    add("C2", "fail" if bad_snap else "pass",
        f"snapshot tidak cocok dengan replay di seq {bad_snap[:5]}" if bad_snap else f"{len(session.get('snapshots', []))} snapshot cocok dengan replay")

    c3 = [i for i, e in enumerate(events)
          if e["type"] in ("key_up", "cursor") and (e["inserted_len"] or e["deleted_len"] or e["len_after"] != e["len_before"])]
    add("C3", "fail" if c3 else "pass",
        f"event non-pengubah-teks mengubah panjang di indeks {c3[:5]}" if c3 else "tidak ada perubahan teks pada event non-pengubah-teks")

    if "tz_offset_min" in session:
        want = session["tz_offset_min"]
        bad = []
        for i, e in enumerate(events):
            if "wall_ts" in e:
                off = parse_ts(e["wall_ts"]).utcoffset().total_seconds() / 60
                if off != want:
                    bad.append(i)
        add("C10", "fail" if bad else "pass",
            f"offset wall_ts berbeda dari tz_offset_min di indeks {bad[:5]}" if bad else "offset zona waktu log selaras",
            note="Dokumen .docx menyimpan waktu dalam UTC (tanpa offset), jadi C10 hanya memeriksa konsistensi internal log.")
    else:
        add("C10", "info", "tz_offset_min tidak direkam (opsional, butuh consent)")

    # ---- C4, C5, C7, C8, C9: dokumen .docx
    if docx_path:
        _docx_checks(docx_path, session, t_start, t_end, cfg, add)
    else:
        for rid in ("C4", "C5", "C7", "C8", "C9"):
            add(rid, "skip", "tidak ada berkas .docx diberikan")

    # ---- P dan D: plausibilitas dan fitur (flag, bukan vonis)
    feats = _plausibility_and_features(events, cfg, add)
    return _finish(results, cfg, session, events, feats, schema_ok)


def _check_signatures(bundle, cfg, add):
    msg = signed_manifest(bundle)
    notes, failed, unverified = [], [], []
    present = {"classical": "sig_classical" in bundle, "pq": "sig_pq" in bundle}
    if cfg["require_classical"] and not present["classical"]:
        failed.append("tanda tangan klasik wajib tetapi tidak ada")
    if cfg["require_pq"] and not present["pq"]:
        failed.append("tanda tangan pascakuantum wajib tetapi tidak ada")
    for kind, field, allowed, fn in (("classical", "sig_classical", cfg["allowed_classical"], _verify_classical),
                                     ("pq", "sig_pq", cfg["allowed_pq"], _verify_pq)):
        if not present[kind]:
            continue
        sig = bundle[field]
        if sig["alg"] not in allowed:
            failed.append(f"{kind}: algoritma {sig['alg']} tidak ada di daftar yang diizinkan")
            continue
        if bundle["alg_ids"].get(kind) != sig["alg"]:
            failed.append(f"{kind}: alg_ids tidak cocok dengan algoritma tanda tangan")
            continue
        res = fn(sig["alg"], msg, sig["signature_b64"], sig["public_key_b64"])
        if res is True:
            notes.append(f"{kind} terverifikasi ({sig['alg']})")
        elif res is False:
            failed.append(f"{kind}: tanda tangan tidak valid")
        else:
            unverified.append(f"{kind}: tidak bisa diverifikasi (pustaka tidak terpasang atau algoritma tidak didukung)")
    if failed:
        add("V10", "fail", "; ".join(failed + notes))
    elif unverified:
        add("V10", "skip", "; ".join(unverified + notes))
    elif not any(present.values()):
        add("V10", "fail", "tidak ada tanda tangan")
    else:
        add("V10", "pass", "; ".join(notes))


# --------------------------------------------------------------------------- docx

def _read_xml(zf, name, cfg):
    info = zf.getinfo(name)
    if info.file_size > cfg["max_uncompressed_bytes"]:
        raise ValueError(f"{name} terlalu besar")
    return ET.fromstring(zf.read(name))


def _referenced_parts(zf, cfg):
    refs = set()
    for name in zf.namelist():
        if not name.endswith(".rels"):
            continue
        base_dir = posixpath.dirname(posixpath.dirname(name))  # '_rels/.rels' -> '', 'word/_rels/x.rels' -> 'word'
        root = _read_xml(zf, name, cfg)
        for rel in root:
            if rel.attrib.get("TargetMode") == "External":
                continue
            target = rel.attrib.get("Target", "")
            path = target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join(base_dir, target))
            refs.add(path)
    return refs


def _docx_checks(path, session, t_start, t_end, cfg, add):
    tol = timedelta(minutes=cfg["docx_tolerance_min"])
    try:
        zf = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError) as e:
        for rid in ("C4", "C5", "C8", "C9"):
            add(rid, "skip", "dokumen tidak bisa dibuka")
        add("C7", "fail", f"bukan wadah ZIP yang valid: {e}")
        return
    with zf:
        infos = zf.infolist()
        total = sum(i.file_size for i in infos)
        comp = sum(i.compress_size for i in infos) or 1
        problems = []
        if total > cfg["max_uncompressed_bytes"] or total / comp > cfg["max_compression_ratio"]:
            add("C7", "fail", "ukuran atau rasio kompresi mencurigakan (potensi zip bomb); pemeriksaan XML dihentikan")
            for rid in ("C4", "C5", "C8", "C9"):
                add(rid, "skip", "dihentikan karena C7 gagal")
            return
        bad = zf.testzip()
        if bad:
            problems.append(f"entri rusak: {bad}")
        try:
            refs = _referenced_parts(zf, cfg)
        except Exception as e:
            refs = set()
            problems.append(f"rels tidak bisa diparse: {e}")
        names = [i.filename for i in infos if not i.filename.endswith("/")]
        unreferenced = sorted(n for n in names if n not in refs and not n.endswith(".rels") and n != "[Content_Types].xml")
        if unreferenced:
            problems.append(f"bagian tidak dirujuk: {unreferenced[:5]}")
        tz = t_start.tzinfo
        out_of_window = []
        for i in infos:
            if i.filename.endswith("/"):
                continue
            ts = datetime(*i.date_time, tzinfo=tz)
            if not (t_start - tol <= ts <= t_end + tol):
                out_of_window.append(i.filename)
        if out_of_window:
            problems.append(f"cap waktu entri di luar jendela sesi: {out_of_window[:5]}")
        add("C7", "fail" if problems else "pass", "; ".join(problems) if problems else "wadah ZIP valid, tidak ada bagian tak dirujuk, cap waktu entri dalam jendela")

        core = app = None
        try:
            if "docProps/core.xml" in zf.namelist():
                core = _read_xml(zf, "docProps/core.xml", cfg)
            if "docProps/app.xml" in zf.namelist():
                app = _read_xml(zf, "docProps/app.xml", cfg)
        except Exception as e:
            add("C4", "skip", f"properti dokumen tidak bisa diparse: {e}")
            core = app = None

        def find(root, tag):
            if root is None:
                return None
            for el in root.iter():
                if _local(el.tag) == tag:
                    return (el.text or "").strip()
            return None

        created, modified = find(core, "created"), find(core, "modified")
        if created and modified:
            c, m = parse_ts(created), parse_ts(modified)
            issues = []
            if not (t_start - tol <= m <= t_end + tol):
                issues.append("modified di luar jendela sesi")
            if c > t_end + tol:
                issues.append("created setelah sesi berakhir")
            if cfg["new_document_expected"] and c < t_start - tol:
                issues.append("created jauh sebelum sesi, padahal dokumen baru diharapkan")
            add("C4", "fail" if issues else "pass", "; ".join(issues) if issues else "created/modified dalam jendela sesi")
        elif core is not None or app is not None:
            add("C4", "skip", "created/modified tidak ada di properti dokumen")

        total_time = find(app, "TotalTime")
        if total_time and total_time.isdigit():
            dur_min = (t_end - t_start).total_seconds() / 60
            ok = int(total_time) <= dur_min + cfg["docx_tolerance_min"]
            add("C5", "pass" if ok else "flag", f"TotalTime {total_time} menit vs durasi sesi {dur_min:.1f} menit")
        else:
            add("C5", "skip", "TotalTime tidak ada")

        # C8: hitung ID revisi; HIPOTESIS belum terverifikasi, jangan dipakai sebagai aturan keras
        try:
            rs = set()
            for part in ("word/document.xml", "word/settings.xml"):
                if part in zf.namelist():
                    for el in _read_xml(zf, part, cfg).iter():
                        for k, v in el.attrib.items():
                            # atribut rsidR, rsidRPr, ... dan elemen <w:rsid w:val="...">
                            if _local(k).startswith("rsid") or (_local(el.tag) == "rsid" and _local(k) == "val"):
                                rs.add(v)
            add("C8", "info", f"{len(rs)} ID revisi (rsid) berbeda", rsid_count=len(rs),
                note="HIPOTESIS belum terverifikasi: kaitan jumlah rsid dengan jumlah sesi penyuntingan harus diuji empiris sebelum dijadikan aturan.")
        except Exception as e:
            add("C8", "skip", f"tidak bisa diparse: {e}")

        application = find(app, "Application")
        expected = session.get("expected_application")
        if expected:
            ok = application is not None and expected.lower() in application.lower()
            add("C9", "pass" if ok else "fail", f"Application={application!r}, diharapkan mengandung {expected!r}")
        else:
            add("C9", "info", f"Application={application!r} (expected_application tidak diisi)")


# --------------------------------------------------------------------------- P dan D

def _plausibility_and_features(events, cfg, add):
    downs = [e for e in events if e["type"] == "key_down"]
    intervals = [downs[i]["t_ms"] - downs[i - 1]["t_ms"] for i in range(1, len(downs))]
    intervals = [x for x in intervals if 0 <= x <= cfg["iki_max_ms"]]
    enough = len(intervals) >= cfg["min_intervals_for_stats"]

    if enough:
        fast = sum(1 for x in intervals if x < cfg["theta_min_iki_ms"]) / len(intervals)
        add("P1", "flag" if fast > cfg["theta_fast_fraction"] else "pass", f"{fast:.1%} interval < {cfg['theta_min_iki_ms']} ms")
        mean = statistics.fmean(intervals)
        cv = statistics.pstdev(intervals) / mean if mean else 0.0
        add("P2", "flag" if cv < cfg["theta_cv_low"] else "pass", f"koefisien variasi interval {cv:.2f}")
        typed_chars = sum(e["inserted_len"] for e in events if e["source"] == "typed")
        span_min = (downs[-1]["t_ms"] - downs[0]["t_ms"]) / 60000 if len(downs) > 1 else 0
        wpm = (typed_chars / 5) / span_min if span_min > 0 else 0.0
        add("P3", "flag" if wpm > cfg["theta_wpm_max"] else "pass", f"kecepatan efektif {wpm:.0f} wpm")
    else:
        for rid in ("P1", "P2", "P3"):
            add(rid, "skip", f"interval tidak cukup (< {cfg['min_intervals_for_stats']})")
        cv = None

    p4 = [i for i, e in enumerate(events)
          if e["type"] == "key_down" and e["inserted_len"] > 0 and e["key_class"] in ("modifier", "nav", "none")]
    add("P4", "flag" if p4 else "pass", f"key_down mengubah teks dengan key_class tak wajar di indeks {p4[:5]}" if p4 else "tidak ada")

    synth = sum(1 for e in events if e["source"] == "synthetic")
    add("P6", "flag" if synth else "pass", f"{synth} event bersumber sintetis")

    # fitur D (flag, bukan keputusan)
    ins = sum(e["inserted_len"] for e in events)
    paste_ins = sum(e["inserted_len"] for e in events if e["source"] == "paste")
    dele = sum(e["deleted_len"] for e in events)
    paste_ratio = paste_ins / ins if ins else 0.0
    delete_ratio = dele / ins if ins else 0.0
    initial_pause = events[0]["t_ms"] if events else 0
    feats = {
        "n_events": len(events), "n_intervals": len(intervals), "iki_cv": cv,
        "paste_ratio": paste_ratio, "delete_ratio": delete_ratio, "initial_pause_ms": initial_pause,
        "synthetic_events": synth,
    }
    add("D1", "flag" if paste_ratio > cfg["theta_paste_ratio"] else "pass",
        f"rasio paste {paste_ratio:.1%} (fitur, bukan vonis)")
    cue = (delete_ratio < cfg["theta_delete_ratio_low"] and initial_pause > cfg["theta_initial_pause_ms"]
           and paste_ratio <= cfg["theta_paste_ratio"] and ins > 0)
    add("D2", "flag" if cue else "pass",
        f"rasio hapus {delete_ratio:.1%}, jeda awal {initial_pause} ms"
        + ("; pola linear tanpa revisi (fitur, bukan vonis)" if cue else ""))
    return feats


# --------------------------------------------------------------------------- keputusan

def _finish(results, cfg, session, events, feats, schema_ok):
    by_id = {r["id"]: r for r in results}
    integrity_fail = [r["id"] for r in results if r["id"] in INTEGRITY_IDS and r["status"] == "fail"]
    consistency_fail = [r["id"] for r in results if r["id"].startswith("C") and r["status"] == "fail"]
    integrity_unverified = [r["id"] for r in results if r["id"] in INTEGRITY_IDS and r["status"] == "skip"]
    if integrity_fail:
        decision = "evidence_integrity_failure"
    elif consistency_fail:
        decision = "inconsistent_log_document"
    elif len(events) < cfg["min_events_for_decision"]:
        decision = "inconclusive_insufficient_data"
    else:
        decision = "no_validator_decision"
    return {
        "session_id": session.get("session_id"),
        "decision": decision,
        "integrity_fully_verified": not integrity_fail and not integrity_unverified,
        "integrity_failed": integrity_fail,
        "integrity_unverified": integrity_unverified,
        "consistency_failed": consistency_fail,
        "flags": [r["id"] for r in results if r["status"] == "flag"],
        "features": feats,
        "results": results,
        "note": ("Validator tidak mengklasifikasi AI vs manusia. 'no_validator_decision' berarti integritas dan "
                 "konsistensi lolos dan fitur/flag boleh diteruskan ke model. Semua ambang adalah placeholder."),
    }


# --------------------------------------------------------------------------- CLI

def _load_events(path):
    out = []
    with open(path, encoding="utf-8") as f:
        for n, line in enumerate(f, 1):
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except json.JSONDecodeError as e:
                    raise SystemExit(f"{path}:{n}: JSON tidak valid: {e}")
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--session", required=True)
    ap.add_argument("--events", required=True)
    ap.add_argument("--bundle", required=True)
    ap.add_argument("--docx")
    ap.add_argument("--config")
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    session = json.loads(Path(a.session).read_text(encoding="utf-8"))
    bundle = json.loads(Path(a.bundle).read_text(encoding="utf-8"))
    events = _load_events(a.events)
    cfg = json.loads(Path(a.config).read_text(encoding="utf-8")) if a.config else None
    report = validate(session, events, bundle, a.docx, cfg)
    text = json.dumps(report, indent=2, ensure_ascii=False)
    if a.out:
        Path(a.out).write_text(text, encoding="utf-8")
    for r in report["results"]:
        print(f"{r['id']:<5}{r['status']:<6}{r['detail']}")
    print(f"\nkeputusan: {report['decision']}  | integritas terverifikasi penuh: {report['integrity_fully_verified']}")
    return 0 if report["decision"] not in ("evidence_integrity_failure", "inconsistent_log_document") else 1


if __name__ == "__main__":
    sys.exit(main())
